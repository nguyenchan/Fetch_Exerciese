for(let j =1; j <= 7; j++){
    let str = '#'.repeat(j);
    console.log(str);
}
